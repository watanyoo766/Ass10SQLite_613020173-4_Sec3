package com.example.lab10sqlite

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.std_item_layout.view.*

class StudentsAdapter (val items :List<Student>,val context: Context):RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    class ViewHolder(view:View): RecyclerView.ViewHolder(view){
        val tvID: TextView = view.tv_id
        val tvName: TextView = view.tv_name
        val tvAge: TextView = view.tv_age
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view_item : View = LayoutInflater.from(parent.context).inflate(R.layout.std_item_layout,parent,false)
        val myHolder = ViewHolder(view_item)
        view_item.setOnClickListener{
            val pos :Int =myHolder.adapterPosition
            val context:Context =parent.context
            val student :Student = items[pos]
            val intent = Intent(context,EditDeleteActivity::class.java)
            intent.putExtra("mid")
        }
    }

    override fun getItemCount(): Int {
        TODO("Not yet implemented")
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        TODO("Not yet implemented")
    }

}